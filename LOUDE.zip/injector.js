(function () {'use strict';

if (window.__Noor404Extreme_loaded) return;
window.__Noor404Extreme_loaded = true;

function createParticleEngine(canvas) {
  const ctx = canvas.getContext('2d');
  const particles = [];

  for (let i = 0; i < 40; i++) {  
    particles.push({  
      x: Math.random() * 300,  
      y: Math.random() * 550,  
      r: Math.random() * 1.8 + 0.5,  
      speed: Math.random() * 0.5 + 0.1,  
      opacity: Math.random() * 0.6 + 0.2  
    });  
  }  

  let animationFrameId = null;  

  const render = () => {  
    animationFrameId = requestAnimationFrame(render);  
    const parent = canvas.parentElement;  
    if (!parent) return;  

    const w = canvas.width = parent.offsetWidth || 300;  
    const h = canvas.height = parent.offsetHeight || 550;  

    ctx.clearRect(0, 0, w, h);  
    ctx.fillStyle = getComputedStyle(canvas.parentElement).getPropertyValue('--accent').trim() || '#ff0000';  

    particles.forEach(p => {  
      p.y -= p.speed;  
      if (p.y < 0) p.y = h;  
      ctx.globalAlpha = p.opacity;  
      ctx.beginPath();  
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);  
      ctx.fill();  
    });  
    ctx.globalAlpha = 1.0;  
  };  

  render();  

  return () => {  
    if (animationFrameId) cancelAnimationFrame(animationFrameId);  
  };
}

function showStatusPopup(messageText, colorHex) {
  const oldPopup = document.getElementById("n404-popup-panel");
  if (oldPopup) oldPopup.remove();

  const panel = document.createElement("aside");  
  panel.id = "n404-popup-panel";  
  panel.style.setProperty('--accent', colorHex);  
  panel.style.setProperty('--border', colorHex);  

  panel.innerHTML = `  
    <canvas id="n404-popup-bg-canvas"></canvas>  
    <div class="n404-header" id="n404-popup-header">  
        <span class="n404-title">EAR | PIERCING HOOK</span>  
        <div class="n404-hdr-btns">  
            <button id="btn-popup-lock" class="n404-action-tag-btn" type="button">LOCK (OFF)</button>  
            <button id="btn-popup-close" class="n404-action-tag-btn" type="button">MINIMIZE (OFF)</button>  
        </div>  
    </div>  
    <div class="n404-popup-body" id="n404-popup-body">  
        <div class="n404-popup-msg" style="color: ${colorHex};">${messageText}</div>  
    </div>  
  `;  

  const style = document.createElement("style");  
  style.textContent = `  
    #n404-popup-panel {  
      position: fixed;  
      top: 30px;  
      left: 30px;  
      width: 330px;  
      background: rgba(12, 12, 16, 0.92);  
      border: 1px solid var(--border);  
      box-shadow: 0 0 15px rgba(0,0,0,0.8), 0 0 10px var(--accent);  
      border-radius: 8px;  
      color: #fff;  
      z-index: 999999999;  
      font-family: 'Segoe UI', system-ui, sans-serif;  
      user-select: none;  
      padding: 12px;  
      backdrop-filter: blur(8px);  
      touch-action: none;  
      overflow: hidden;  
    }  
    #n404-popup-bg-canvas {  
      position: absolute;  
      top: 0; left: 0; width: 100%; height: 100%;  
      pointer-events: none;  
      z-index: 0;  
    }  
    #n404-popup-panel .n404-header,  
    #n404-popup-panel .n404-popup-body {  
      position: relative;  
      z-index: 1;  
    }  
    #n404-popup-panel .n404-header {  
      display: flex;  
      justify-content: space-between;  
      align-items: center;  
      border-bottom: 1px solid var(--border);  
      padding-bottom: 8px;  
      cursor: move;  
      touch-action: none;  
    }  
    #n404-popup-panel .n404-title {  
      font-size: 11px;  
      font-weight: 800;  
      color: var(--accent);  
      letter-spacing: 1px;  
    }  
    #n404-popup-panel .n404-popup-body {  
      padding: 24px 10px;  
      text-align: center;  
    }  
    #n404-popup-panel .n404-popup-msg {  
      font-size: 14px;  
      font-weight: 700;  
      letter-spacing: 0.5px;  
    }  
    #n404-popup-panel .n404-hdr-btns {  
      display: flex;  
      gap: 4px;  
    }  
    #n404-popup-panel .n404-action-tag-btn {  
      background: transparent;  
      border: 1px solid var(--border);  
      color: var(--accent);  
      font-weight: bold;  
      font-size: 8px;  
      padding: 3px 5px;  
      border-radius: 3px;  
      cursor: pointer;  
      transition: 0.2s;  
      pointer-events: auto;  
    }  
    #n404-popup-panel .n404-action-tag-btn.active,   
    #n404-popup-panel .n404-action-tag-btn:hover {  
      background: var(--accent);  
      color: #000;  
      box-shadow: 0 0 8px var(--accent);  
    }  
  `;  

  document.head.appendChild(style);  
  document.body.appendChild(panel);  

  const popupCanvas = panel.querySelector("#n404-popup-bg-canvas");  
  if (popupCanvas) {  
    createParticleEngine(popupCanvas);  
  }  

  const btnLock = panel.querySelector("#btn-popup-lock");  
  const btnClose = panel.querySelector("#btn-popup-close");  
  const popupBody = panel.querySelector("#n404-popup-body");  

  let isLocked = false;  
  let isCollapsed = false;  

  btnLock.addEventListener("click", (e) => {  
    e.stopPropagation();  
    isLocked = !isLocked;  
    panel.dataset.locked = isLocked;  
    btnLock.textContent = isLocked ? "LOCK (ON)" : "LOCK (OFF)";  
    btnLock.classList.toggle("active", isLocked);  
  });  

  btnClose.addEventListener("click", (e) => {  
    e.stopPropagation();  
    isCollapsed = !isCollapsed;  
    popupBody.style.display = isCollapsed ? "none" : "block";  
    btnClose.textContent = isCollapsed ? "MINIMIZE (ON)" : "MINIMIZE (OFF)";  
    btnClose.classList.toggle("active", isCollapsed);  
  });  

  enablePopupDrag(panel, () => isLocked);
}

function enablePopupDrag(panel, isLockedFn) {
  const header = panel.querySelector("#n404-popup-header");
  let isDragging = false;
  let startX = 0, startY = 0;
  let initialLeft = 0, initialTop = 0;

  const onStart = (clientX, clientY, target) => {  
    if (isLockedFn && isLockedFn()) return;  
    if (target.closest(".n404-hdr-btns")) return;  

    isDragging = true;  
    startX = clientX;  
    startY = clientY;  
    initialLeft = panel.offsetLeft;  
    initialTop = panel.offsetTop;  
  };  

  const onMove = (clientX, clientY, e) => {  
    if (!isDragging) return;  
    if (e && e.cancelable) e.preventDefault();  

    const dx = clientX - startX;  
    const dy = clientY - startY;  

    const maxX = window.innerWidth - panel.offsetWidth;  
    const maxY = window.innerHeight - panel.offsetHeight;  

    panel.style.left = Math.min(Math.max(0, initialLeft + dx), maxX) + 'px';  
    panel.style.top = Math.min(Math.max(0, initialTop + dy), maxY) + 'px';  
  };  

  const onEnd = () => { isDragging = false; };  

  header.addEventListener("mousedown", e => onStart(e.clientX, e.clientY, e.target));  
  window.addEventListener("mousemove", e => onMove(e.clientX, e.clientY, e));  
  window.addEventListener("mouseup", onEnd);  

  header.addEventListener("touchstart", e => {  
    if (e.touches.length === 1) onStart(e.touches[0].clientX, e.touches[0].clientY, e.target);  
  }, { passive: false });  

  window.addEventListener("touchmove", e => {  
    if (isDragging && e.touches.length === 1) onMove(e.touches[0].clientX, e.touches[0].clientY, e);  
  }, { passive: false });  

  window.addEventListener("touchend", onEnd);
}

window.addEventListener("message", (event) => {
  if (event.data && event.data.type === "NOOR404_SERVER_STATUS") {
    const statusData = event.data.statusData;

    if (!statusData || !statusData.success || !statusData.data) {  
      showStatusPopup("Tool is Currently Offline.", "#ff3333");  
      return;  
    }  

    const data = statusData.data;  
    const status = (data && data.status) ? data.status.trim() : "";  

    if (status === "Online" || status === "online") {  
      const oldPopup = document.getElementById("n404-popup-panel");  
      if (oldPopup) oldPopup.remove();  
      initMainEngine();  
    } else if (status === "Offline" || status === "offline") {  
      showStatusPopup("Tool is Currently Offline.", "#ff3333");  
    } else if (status === "maintenance" || status === "Maintenance") {  
      showStatusPopup("Tool is Currently Maintenance.", "#ffaa00");  
    } else {  
      showStatusPopup("Tool is Currently Offline.", "#ff3333");  
    }  
  }
});

function initMainEngine() {
  const resumeAudio = () => {
    if (window.__Noor404AudioCtx && window.__Noor404AudioCtx.state === 'suspended') {
      window.__Noor404AudioCtx.resume();
    }
  };

  window.addEventListener('click', resumeAudio, { once: true });  
  window.addEventListener('touchstart', resumeAudio, { once: true });  

  const DEFAULT_CONFIG = Object.freeze({  
    talkSet: 0,  
    masterGain: 1000,  
    rageBoost: 0,  
    bitrate: 2500,  
    stereoWidth: 1.0,  
    eq1: 0,  
    eq2: 0,  
    eq3: 0,  
    eq4: 0,  
    eq5: 0,  
    eq6: 0,  
    customColor: "#ff0000",  
    turboActive: false,  
    muteActive: false,  
    louderDisabled: false,  
    panelLocked: false,  
    collapsed: false,  
    panelX: 20,  
    panelY: 20,
    repeatState: 0
  });  

  const currentState = Object.seal({ ...DEFAULT_CONFIG });  

  try {  
    localStorage.removeItem("noor404-extreme-hybrid-state");  
  } catch (e) {}  

  const NativeAudioContext = window.AudioContext || window.webkitAudioContext;  
  let workletPromise = null;  

  window.AudioContext = class extends NativeAudioContext {  
    constructor(opts) {  
      super(opts || { latencyHint: "interactive", sampleRate: 48000 });  
      window.__Noor404AudioCtx = this;  

      const workletCode = `  
        class Noor404Processor extends AudioWorkletProcessor {  
            constructor() {
                super();
                this.isRecording = false;
                this.port.onmessage = (e) => {
                    if (e.data && e.data.type === 'SET_RECORDING') {
                        this.isRecording = e.data.value;
                    }
                };
            }

            static get parameterDescriptors() {  
                return [  
                    { name: 'talkSet', defaultValue: 0.0, minValue: 0, maxValue: 100 },  
                    { name: 'masterGain', defaultValue: 1000.0, minValue: 0, maxValue: 10000000 },  
                    { name: 'rage', defaultValue: 0.0, minValue: 0, maxValue: 10000000 },  
                    { name: 'bitrate', defaultValue: 2500, minValue: 1, maxValue: 2500 },  
                    { name: 'width', defaultValue: 1.0, minValue: 0, maxValue: 10 },  
                    { name: 'mute', defaultValue: 0, minValue: 0, maxValue: 1 },  
                    { name: 'louderDisabled', defaultValue: 0, minValue: 0, maxValue: 1 }  
                ];  
            }  

            hardClipDistortion(x) {  
                return Math.max(-0.99, Math.min(0.99, x));  
            }  

            process(inputs, outputs, params) {  
                const input = inputs[0];  
                const output = outputs[0];  
                if (!input || !input.length || !input[0].length) return true;  

                if (this.isRecording && input[0]) {
                    this.port.postMessage({ type: 'pcm', data: input[0].slice() });
                }

                const channelCount = input.length;  
                const frameLength = input[0].length;  
                const hasStereo = channelCount >= 2;  

                for (let i = 0; i < frameLength; i++) {  
                    const talkSet = params.talkSet.length > 1 ? params.talkSet[i] : params.talkSet[0];  
                    const masterGain = params.masterGain.length > 1 ? params.masterGain[i] : params.masterGain[0];  
                    const rage = params.rage.length > 1 ? params.rage[i] : params.rage[0];  
                    const bitrate = params.bitrate.length > 1 ? params.bitrate[i] : params.bitrate[0];  
                    const widthVal = params.width.length > 1 ? params.width[i] : params.width[0];  
                    const mute = params.mute.length > 1 ? params.mute[i] : params.mute[0];  
                    const louderDisabled = params.louderDisabled.length > 1 ? params.louderDisabled[i] : params.louderDisabled[0];  

                    const processed = new Array(channelCount);  

                    for (let ch = 0; ch < channelCount; ch++) {  
                        let s = input[ch][i];  

                        if (mute > 0.5) {  
                            processed[ch] = 0;  
                            continue;  
                        }  

                        if (louderDisabled > 0.5) {  
                            if (talkSet > 0) {  
                                const threshold = (talkSet / 100) * 0.05;  
                                if (Math.abs(s) < threshold) {  
                                    s = 0;  
                                } else {  
                                    s *= (1 + (talkSet / 10));  
                                }  
                            }  
                            processed[ch] = Math.max(-0.9999, Math.min(0.9999, s));  
                            continue;  
                        }  

                        const threshold = (talkSet / 100) * 0.05;  
                        if (Math.abs(s) < threshold) {  
                            s = 0;  
                        } else {  
                            s *= (1 + (talkSet / 10));  
                        }  

                        if (bitrate < 2500) {  
                            const step = 1 / (bitrate / 20);  
                            s = Math.round(s / step) * step;  
                        }  

                        const megaBoost = (masterGain) * (1.0 + (rage / 100.0));
                        s *= megaBoost;
                        s = this.hardClipDistortion(s);

                        processed[ch] = s;  
                    }  

                    if (hasStereo && louderDisabled <= 0.5) {  
                        const L = processed[0];  
                        const R = processed[1];  
                        const mid = (L + R) * 0.5;  
                        const side = (L - R) * 0.5;  
                        processed[0] = Math.max(-0.9999, Math.min(0.9999, mid + side * widthVal));  
                        processed[1] = Math.max(-0.9999, Math.min(0.9999, mid - side * widthVal));  
                    }  

                    for (let ch = 0; ch < channelCount; ch++) {  
                        output[ch][i] = processed[ch];  
                    }  
                }  
                return true;  
            }  
        }  
        registerProcessor('noor404-processor', Noor404Processor);  
      `;  

      const blobUrl = URL.createObjectURL(new Blob([workletCode], { type: "application/javascript" }));  
      workletPromise = this.audioWorklet.addModule(blobUrl)  
        .then(() => {  
          URL.revokeObjectURL(blobUrl);  
          if (window.__Noor404PanelReady) window.__Noor404PanelReady.setStatus("ULTIMATE SOUND ONLINE");  
        })  
        .catch(() => {  
          if (window.__Noor404PanelReady) window.__Noor404PanelReady.setStatus("WORKLET FAIL");  
        });  
    }  
  };  
  Object.defineProperty(window.AudioContext, "name", { value: "AudioContext" });  

  function forceStereoOpusSDP(sdp) {  
    const match = sdp.match(/a=rtpmap:(\d+) opus\/48000/);  
    if (!match) return sdp;  

    const payloadType = match[1];  
    const fmtpRegex = new RegExp(`a=fmtp:${payloadType} [^\\r\\n]+`);  
    const customFmtp = `a=fmtp:${payloadType} minptime=10;useinbandfec=1;usedtx=0;stereo=1;maxaveragebitrate=510000;maxplaybackrate=48000;sprop-maxcapturerate=48000;cbr=1`;  

    if (fmtpRegex.test(sdp)) {  
      sdp = sdp.replace(fmtpRegex, customFmtp);  
    } else {  
      sdp = sdp.replace(new RegExp(`(a=rtpmap:${payloadType} opus\\/48000\\/2)`), `$1\r\n${customFmtp}`);  
    }  
    return sdp.replace(/b=AS:\d+/g, "b=AS:510");  
  }  

  const NativePeerConnection = window.RTCPeerConnection;  
  if (NativePeerConnection) {  
    window.RTCPeerConnection = class extends NativePeerConnection {  
      async createOffer(options) {  
        const offer = await super.createOffer(options);  
        offer.sdp = forceStereoOpusSDP(offer.sdp);  
        return offer;  
      }  
      async createAnswer(options) {  
        const answer = await super.createAnswer(options);  
        answer.sdp = forceStereoOpusSDP(answer.sdp);  
        return answer;  
      }  
      async setLocalDescription(desc) {  
        if (desc && desc.sdp) desc = new RTCSessionDescription({ type: desc.type, sdp: forceStereoOpusSDP(desc.sdp) });  
        return super.setLocalDescription(desc);  
      }  
      async setRemoteDescription(desc) {  
        if (desc && desc.sdp) desc = new RTCSessionDescription({ type: desc.type, sdp: forceStereoOpusSDP(desc.sdp) });  
        return super.setRemoteDescription(desc);  
      }  
    };  
    Object.defineProperty(window.RTCPeerConnection, "name", { value: "RTCPeerConnection" });  
  }  

  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {  
    const origGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);  
    navigator.mediaDevices.getUserMedia = async function (constraints) {  
      if (constraints && constraints.audio) {  
        constraints.audio = {  
          echoCancellation: false,  
          noiseSuppression: false,  
          autoGainControl: false,  
          channelCount: 2,  
          sampleRate: 48000,  
          sampleSize: 16  
        };  
      }  
      const stream = await origGetUserMedia(constraints);  
      if (constraints && constraints.audio && stream.getAudioTracks().length > 0) {  
        return await AudioInterceptor.intercept(stream);  
      }  
      return stream;  
    };  
  }  

  const AudioInterceptor = {  
    workletNode: null,  
    analyserNode: null,  
    sourceNode: null,  
    eqNodes: [],  
    pushScheduled: false,  
    mediaStream: null,
    recordedPCMChunks: [],
    illusionInterval: null,

    async intercept(mediaStream) {  
      this.mediaStream = mediaStream;
      let audioCtx = window.__Noor404AudioCtx;  
      if (!audioCtx || audioCtx.state === "closed") {  
        audioCtx = new window.AudioContext();  
      }  

      if (audioCtx.state === "suspended") {  
        await audioCtx.resume();  
      }  

      if (workletPromise) await workletPromise;  

      this.cleanup();  

      const source = audioCtx.createMediaStreamSource(mediaStream);  
      const destination = audioCtx.createMediaStreamDestination();  

      try {  
        this.sourceNode = source;  
        this.workletNode = new AudioWorkletNode(audioCtx, "noor404-processor");  

        this.recordedPCMChunks = [];
        this.workletNode.port.onmessage = (e) => {
          if (e.data && e.data.type === 'pcm') {
            if (currentState.repeatState === 1) {
              this.recordedPCMChunks.push(e.data.data);
            }
          }
        };

        const freqs = [100, 250, 1000, 3000, 6000, 12000];  
        const types = ["lowshelf", "peaking", "peaking", "peaking", "peaking", "highshelf"];  

        this.eqNodes = freqs.map((freq, i) => {  
          const filter = audioCtx.createBiquadFilter();  
          filter.type = types[i];  
          filter.frequency.value = freq;  
          return filter;  
        });  

        source.connect(this.workletNode);  
          
        let lastNode = this.workletNode;  
        for (const eqNode of this.eqNodes) {  
          lastNode.connect(eqNode);  
          lastNode = eqNode;  
        }  

        this.analyserNode = audioCtx.createAnalyser();  
        this.analyserNode.fftSize = 512;  

        lastNode.connect(this.analyserNode);  
        this.analyserNode.connect(destination);  

        window.__Noor404Analyser = this.analyserNode;  

        const track = mediaStream.getAudioTracks()[0];  
        if (track) {  
          track.addEventListener('ended', () => {  
            this.cleanup();  
          });  
        }  

        this.pushParamsFast();  
        return destination.stream;  
      } catch (err) {  
        if (window.__Noor404PanelReady) window.__Noor404PanelReady.setStatus("FALLBACK MIC");  
        return mediaStream;  
      }  
    },  

    async startVoiceRecording() {
      let audioCtx = window.__Noor404AudioCtx;
      if (!audioCtx || audioCtx.state === "closed") {
        audioCtx = new window.AudioContext();
      }
      if (audioCtx.state === "suspended") {
        await audioCtx.resume();
      }

      if (!this.workletNode) {
        if (window.__Noor404PanelReady) window.__Noor404PanelReady.setStatus("PLEASE TURN ON MIC FIRST");
        return;
      }

      this.stopVoiceRepeat();
      this.recordedPCMChunks = [];

      currentState.repeatState = 1;
      this.workletNode.port.postMessage({ type: 'SET_RECORDING', value: true });

      if (window.__Noor404PanelReady) {
        window.__Noor404PanelReady.updateRepeatButton();
        window.__Noor404PanelReady.setStatus("RECORDING VOICE...");
      }
    },

    stopVoiceRecordingAndStartLoop() {
      if (!this.workletNode) return;

      this.workletNode.port.postMessage({ type: 'SET_RECORDING', value: false });

      let totalSamples = this.recordedPCMChunks.reduce((acc, chunk) => acc + chunk.length, 0);

      if (totalSamples === 0) {
        currentState.repeatState = 0;
        if (window.__Noor404PanelReady) {
          window.__Noor404PanelReady.updateRepeatButton();
          window.__Noor404PanelReady.setStatus("NO VOICE DATA");
        }
        return;
      }

      let merged = new Float32Array(totalSamples);
      let offset = 0;
      for (let chunk of this.recordedPCMChunks) {
        merged.set(chunk, offset);
        offset += chunk.length;
      }

      // Trimming background silent margins
      let threshold = 0.015;
      let start = 0;
      let end = totalSamples - 1;

      while (start < totalSamples && Math.abs(merged[start]) < threshold) {
        start++;
      }
      while (end > start && Math.abs(merged[end]) < threshold) {
        end--;
      }

      if (end <= start) {
        start = 0;
        end = totalSamples - 1;
      }

      let trimmed = new Float32Array(merged.subarray(start, end + 1));

      // Peak Normalization for full repeat volume
      let maxPeak = 0;
      for (let i = 0; i < trimmed.length; i++) {
        let abs = Math.abs(trimmed[i]);
        if (abs > maxPeak) maxPeak = abs;
      }
      if (maxPeak > 0) {
        let normFactor = 0.9 / maxPeak;
        for (let i = 0; i < trimmed.length; i++) {
          trimmed[i] *= normFactor;
        }
      }

      let audioCtx = window.__Noor404AudioCtx;
      // 2-channel stereo audio buffer creation
      let buffer = audioCtx.createBuffer(2, trimmed.length, audioCtx.sampleRate);
      buffer.getChannelData(0).set(trimmed);
      buffer.getChannelData(1).set(trimmed);

      if (this.illusionInterval) {
        clearInterval(this.illusionInterval);
        this.illusionInterval = null;
      }

      currentState.repeatState = 2;

      let soundDuration = buffer.duration;
      let overlapDelay = Math.max(0.1, soundDuration * 0.72); 

      const triggerOverlapVoice = () => {
        if (currentState.repeatState !== 2) return;
        let node = audioCtx.createBufferSource();
        node.buffer = buffer;
        node.playbackRate.value = 1.0;
        node.connect(this.workletNode);
        node.start(0);
      };

      triggerOverlapVoice(); 

      this.illusionInterval = setInterval(() => {
        if (currentState.repeatState !== 2) {
          clearInterval(this.illusionInterval);
          this.illusionInterval = null;
          return;
        }
        triggerOverlapVoice(); 
      }, overlapDelay * 1000);

      if (window.__Noor404PanelReady) {
        window.__Noor404PanelReady.updateRepeatButton();
        window.__Noor404PanelReady.setStatus("FULL VOICE ILLUSION ACTIVE...");
      }
    },

    stopVoiceRepeat() {
      if (this.workletNode) {
        try { this.workletNode.port.postMessage({ type: 'SET_RECORDING', value: false }); } catch(e){}
      }
      if (this.illusionInterval) {
        clearInterval(this.illusionInterval);
        this.illusionInterval = null;
      }
      currentState.repeatState = 0;
      if (window.__Noor404PanelReady) {
        window.__Noor404PanelReady.updateRepeatButton();
      }
    },

    cleanup() {  
      this.stopVoiceRepeat();
      try { if (this.sourceNode) this.sourceNode.disconnect(); } catch (e) {}  
      try { if (this.workletNode) this.workletNode.disconnect(); } catch (e) {}  
      try { this.eqNodes.forEach(n => n.disconnect()); } catch (e) {}  
      try { if (this.analyserNode) this.analyserNode.disconnect(); } catch (e) {}  

      this.sourceNode = null;  
      this.workletNode = null;  
      this.analyserNode = null;  
      this.eqNodes = [];  
      this.mediaStream = null;
      window.__Noor404Analyser = null;  

      const canvas = document.getElementById("n404-canvas");  
      if (canvas) {  
        const ctx = canvas.getContext('2d');  
        ctx.clearRect(0, 0, canvas.width, canvas.height);  
        ctx.fillStyle = currentState.customColor || '#ff0000';  
        ctx.fillRect(0, canvas.height / 2, canvas.width, 2);  
      }  
    },  

    schedulePushParams() {  
      if (this.pushScheduled) return;  
      this.pushScheduled = true;  
      requestAnimationFrame(() => {  
        this.pushScheduled = false;  
        this.pushParamsFast();  
      });  
    },  

    pushParamsFast() {  
      if (!this.workletNode || !window.__Noor404AudioCtx) return;  

      const params = this.workletNode.parameters;  
      const now = window.__Noor404AudioCtx.currentTime;  

      let tSet = currentState.talkSet;  
      let mGain = currentState.turboActive ? 10000000 : currentState.masterGain;  
      let rage = currentState.turboActive ? 10000000 : currentState.rageBoost;  
      let bitrate = currentState.bitrate;  
      let width = currentState.stereoWidth;  
      let mute = currentState.muteActive ? 1 : 0;  
      let louderDisabled = currentState.louderDisabled ? 1 : 0;  

      let statusMsg = "MAX LOUDNESS ACTIVE";  
      if (currentState.muteActive) {  
        statusMsg = "MUTED";  
      } else if (currentState.repeatState === 1) {
        statusMsg = "RECORDING VOICE...";
      } else if (currentState.repeatState === 2) {
        statusMsg = "FULL VOICE ILLUSION ACTIVE...";
      } else if (currentState.louderDisabled) {  
        if (currentState.talkSet > 0) {  
          statusMsg = "TALK SET MODE (LOUDER OFF)";  
        } else {  
          statusMsg = "CRYSTAL CLEAR MODE (LOUDER OFF)";  
        }  
      } else if (currentState.talkSet > 0) {  
        statusMsg = "TALK SET MODE (ACTIVE)";  
      } else if (currentState.turboActive) {  
        statusMsg = "ULTIMATE TURBO BOOST";  
      }  

      params.get("talkSet").setValueAtTime(tSet, now);  
      params.get("masterGain").setValueAtTime(mGain, now);  
      params.get("rage").setValueAtTime(rage, now);  
      params.get("bitrate").setValueAtTime(bitrate, now);  
      params.get("width").setValueAtTime(width, now);  
      params.get("mute").setValueAtTime(mute, now);  
      params.get("louderDisabled").setValueAtTime(louderDisabled, now);  

      if (this.eqNodes.length === 6) {  
        for (let i = 0; i < 6; i++) {  
          let eqVal = currentState.louderDisabled ? 0 : currentState[`eq${i + 1}`];  
          this.eqNodes[i].gain.setValueAtTime(eqVal, now);  
        }  
      }  

      if (window.__Noor404PanelReady) window.__Noor404PanelReady.setStatus(statusMsg);  
    }  
  };  

  const UIController = {  
    init() {  
      this.injectStyles();  
      this.build();  
      this.bind();  
      this.enableDrag();  
      this.initColorPalette();  
      this.applyCustomColor(currentState.customColor || "#ff0000");  
      this.applyFromState();  
      this.setStatus("MAX POWER");  

      window.__Noor404PanelReady = this;  

      const mainBgCanvas = document.getElementById("n404-bg-canvas");  
      if (mainBgCanvas) {  
        createParticleEngine(mainBgCanvas);  
      }  

      this.startVisualizer();  
    },  

    resetToDefaults() {  
      AudioInterceptor.stopVoiceRepeat();
      currentState.talkSet = DEFAULT_CONFIG.talkSet;  
      currentState.masterGain = DEFAULT_CONFIG.masterGain;  
      currentState.rageBoost = DEFAULT_CONFIG.rageBoost;  
      currentState.bitrate = DEFAULT_CONFIG.bitrate;  
      currentState.stereoWidth = DEFAULT_CONFIG.stereoWidth;  
        
      currentState.eq1 = DEFAULT_CONFIG.eq1;  
      currentState.eq2 = DEFAULT_CONFIG.eq2;  
      currentState.eq3 = DEFAULT_CONFIG.eq3;  
      currentState.eq4 = DEFAULT_CONFIG.eq4;  
      currentState.eq5 = DEFAULT_CONFIG.eq5;  
      currentState.eq6 = DEFAULT_CONFIG.eq6;  
        
      currentState.turboActive = false;  
      currentState.louderDisabled = false;  
      currentState.muteActive = false;  

      this.applyFromState();  
      AudioInterceptor.pushParamsFast();  
    },  

    startVisualizer() {  
      const canvas = document.getElementById("n404-canvas");  
      if (!canvas) return;  
      const ctx = canvas.getContext('2d');  

      const render = () => {  
        requestAnimationFrame(render);  
        if (currentState.collapsed) return;  

        const width = canvas.width = canvas.offsetWidth || 280;  
        const height = canvas.height = canvas.offsetHeight || 50;  

        ctx.clearRect(0, 0, width, height);  

        const analyser = window.__Noor404Analyser;  
        if (analyser) {  
          const bufferLength = analyser.frequencyBinCount;  
          const dataArray = new Uint8Array(bufferLength);  
          analyser.getByteFrequencyData(dataArray);  

          const barWidth = (width / bufferLength) * 2;  
          let x = 0;  

          for (let i = 0; i < bufferLength; i++) {  
            const barHeight = (dataArray[i] / 255) * height;  
            ctx.fillStyle = currentState.customColor || '#ff0000';  
            ctx.fillRect(x, height - barHeight, barWidth, barHeight);  
            x += barWidth + 1;  
          }  
        } else {  
          ctx.fillStyle = currentState.customColor || '#ff0000';  
          ctx.fillRect(0, height / 2, width, 2);  
        }  
      };  
      render();  
    },  

    setStatus(text) {  
      const el = document.getElementById("n404-status");  
      if (el) el.textContent = text;  
    },  

    updateRepeatButton() {
      const btnRepeat = document.getElementById("btn-repeat");
      if (!btnRepeat) return;
      if (currentState.repeatState === 0) {
        btnRepeat.textContent = "REPEAT (OFF)";
        btnRepeat.classList.remove("active");
      } else if (currentState.repeatState === 1) {
        btnRepeat.textContent = "🔴 RECORDING...";
        btnRepeat.classList.add("active");
      } else if (currentState.repeatState === 2) {
        btnRepeat.textContent = "⚡ REPEATING (ON)";
        btnRepeat.classList.add("active");
      }
    },

    applyCustomColor(colorHex) {  
      currentState.customColor = colorHex;  
      const panel = document.getElementById("n404-panel");  
      if (panel) {  
        panel.style.setProperty('--accent', colorHex);  
        panel.style.setProperty('--border', colorHex);  
      }  
    },  

    initColorPalette() {  
      const canvas = document.getElementById("n404-palette-canvas");  
      const dot = document.getElementById("n404-color-dot");  
      if (!canvas || !dot) return;  

      const ctx = canvas.getContext("2d", { willReadFrequently: true });  
      const w = canvas.width = 250;  
      const h = canvas.height = 30;  

      const grad = ctx.createLinearGradient(0, 0, w, 0);  
      grad.addColorStop(0, "hsl(0, 100%, 50%)");  
      grad.addColorStop(0.17, "hsl(60, 100%, 50%)");  
      grad.addColorStop(0.33, "hsl(120, 100%, 50%)");  
      grad.addColorStop(0.5, "hsl(180, 100%, 50%)");  
      grad.addColorStop(0.67, "hsl(240, 100%, 50%)");  
      grad.addColorStop(0.83, "hsl(300, 100%, 50%)");  
      grad.addColorStop(1, "hsl(360, 100%, 50%)");  

      ctx.fillStyle = grad;  
      ctx.fillRect(0, 0, w, h);  

      let isSelecting = false;  

      const pickColor = (clientX) => {  
        const rect = canvas.getBoundingClientRect();  
        let x = Math.min(Math.max(0, clientX - rect.left), rect.width);  
        const scaleX = w / rect.width;  
        const pxX = Math.min(Math.max(0, Math.floor(x * scaleX)), w - 1);  

        const pixel = ctx.getImageData(pxX, 15, 1, 1).data;  
        const hex = "#" + ((1 << 24) + (pixel[0] << 16) + (pixel[1] << 8) + pixel[2]).toString(16).slice(1);  

        dot.style.left = `${x}px`;  
        this.applyCustomColor(hex);  
      };  

      const handleStart = (e) => {  
        isSelecting = true;  
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;  
        pickColor(clientX);  
      };  

      const handleMove = (e) => {  
        if (!isSelecting) return;  
        if (e.cancelable) e.preventDefault();  
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;  
        pickColor(clientX);  
      };  

      const handleEnd = () => { isSelecting = false; };  

      canvas.parentElement.addEventListener("mousedown", handleStart);  
      window.addEventListener("mousemove", handleMove);  
      window.addEventListener("mouseup", handleEnd);  

      canvas.parentElement.addEventListener("touchstart", handleStart, { passive: false });  
      window.addEventListener("touchmove", handleMove, { passive: false });  
      window.addEventListener("touchend", handleEnd);  
    },  

    updateValueLabel(key) {  
      const lbl = document.getElementById("lbl-" + key);  
      if (!lbl) return;  
      let val = currentState[key];  
      if (key === "talkSet") {  
        val = val.toFixed(0) + '%';  
      } else if (key === "masterGain") {  
        val = val.toFixed(0) + 'x';  
      } else if (key === "rageBoost") {  
        val = val + '%';  
      } else if (key === "stereoWidth") {  
        val = val.toFixed(2) + 'x';  
      } else if (key.startsWith("eq")) {  
        val = (val > 0 ? "+" : "") + val.toFixed(1) + "dB";  
      }  
      lbl.textContent = val;  
    },  

    applyFromState() {  
      const panel = document.getElementById("n404-panel");  
      const body = document.getElementById("n404-body");  

      if (panel) {  
        panel.style.left = currentState.panelX + 'px';  
        panel.style.top = currentState.panelY + 'px';  
      }  

      if (body) {  
        body.style.display = currentState.collapsed ? "none" : 'block';  
      }  

      const btnMute = document.getElementById("btn-mute");  
      if (btnMute) {  
        btnMute.textContent = currentState.muteActive ? "UNMUTE" : "MUTE";  
        btnMute.classList.toggle("active", currentState.muteActive);  
      }  

      const btnTurbo = document.getElementById("btn-turbo");  
      if (btnTurbo) {  
        btnTurbo.textContent = currentState.turboActive ? "MAX BOOST (ON)" : "MAX BOOST (OFF)";  
        btnTurbo.classList.toggle("active", currentState.turboActive);  
      }  

      const btnToggleLouder = document.getElementById("btn-toggle-louder");  
      if (btnToggleLouder) {  
        btnToggleLouder.textContent = currentState.louderDisabled ? "LOUDER (OFF)" : "LOUDER (ON)";  
        btnToggleLouder.classList.toggle("active", !currentState.louderDisabled);  
      }  

      const btnLock = document.getElementById("btn-lock");  
      if (btnLock) {  
        btnLock.textContent = currentState.panelLocked ? "LOCK (ON)" : "LOCK (OFF)";  
        btnLock.classList.toggle("active", currentState.panelLocked);  
      }  

      const btnCollapse = document.getElementById("btn-collapse");  
      if (btnCollapse) {  
        btnCollapse.textContent = currentState.collapsed ? "MINIMIZE (ON)" : "MINIMIZE (OFF)";  
        btnCollapse.classList.toggle("active", currentState.collapsed);  
      }  

      this.updateRepeatButton();

      ["talkSet", "masterGain", "rageBoost", "bitrate", "stereoWidth", "eq1", "eq2", "eq3", "eq4", "eq5", "eq6"].forEach(key => {  
        const input = document.querySelector(`#n404-panel input[data-param="${key}"]`);  
        if (input) input.value = String(currentState[key]);  
        this.updateValueLabel(key);  
      });  
    },  

    build() {  
      const panel = document.createElement("aside");  
      panel.id = "n404-panel";  
      panel.innerHTML = `  
        <canvas id="n404-bg-canvas"></canvas>  
        <div class="n404-header" id="n404-header">  
            <span class="n404-title">EAR | PIERCING HOOK</span>  
            <div class="n404-hdr-btns">  
                <button id="btn-lock" class="n404-action-tag-btn" type="button">LOCK (OFF)</button>  
                <button id="btn-collapse" class="n404-action-tag-btn" type="button">MINIMIZE (OFF)</button>  
            </div>  
        </div>  

        <div id="n404-body">  
            <div class="n404-visual">  
                <canvas id="n404-canvas"></canvas>  
            </div>  

            <div class="n404-bar">  
                <span class="n404-dot"></span>  
                <span id="n404-status">INITIALIZING</span>  
            </div>  

            <div class="n404-palette-box">  
                <div class="n404-lbl">CUSTOM COLOR PALETTE</div>  
                <div class="n404-palette-container">  
                    <canvas id="n404-palette-canvas"></canvas>  
                    <div id="n404-color-dot"></div>  
                </div>  
            </div>  

            <div class="n404-sliders">  
                <div class="n404-field">  
                    <div class="n404-lbl">TALK SET <span id="lbl-talkSet">0%</span></div>  
                    <input data-param="talkSet" type="range" min="0" max="100" step="1" value="0">  
                </div>  

                <div class="n404-field">  
                    <div class="n404-lbl">EXTREME MASTER <span id="lbl-masterGain">1000x</span></div>  
                    <input data-param="masterGain" type="range" min="1" max="10000000" step="1000" value="1000">  
                </div>  

                <div class="n404-field">  
                    <div class="n404-lbl">RAGE BOOST <span id="lbl-rageBoost">0%</span></div>  
                    <input data-param="rageBoost" type="range" min="0" max="10000000" step="1000" value="0">  
                </div>  

                <div class="n404-field">  
                    <div class="n404-lbl">BITRATE (LO-FI) <span id="lbl-bitrate">2500</span></div>  
                    <input data-param="bitrate" type="range" min="1" max="2500" step="1" value="2500">  
                </div>  

                <div class="n404-field">  
                    <div class="n404-lbl">STEREO WIDTH <span id="lbl-stereoWidth">1.0x</span></div>  
                    <input data-param="stereoWidth" type="range" min="0" max="10" step="0.05" value="1.0">  
                </div>  

                <div class="n404-eq-grid">  
                    <div class="n404-field"><div class="n404-lbl">100Hz <span id="lbl-eq1">+0.0dB</span></div><input data-param="eq1" type="range" min="-24" max="48" step="0.5" value="0"></div>  
                    <div class="n404-field"><div class="n404-lbl">250Hz <span id="lbl-eq2">+0.0dB</span></div><input data-param="eq2" type="range" min="-24" max="48" step="0.5" value="0"></div>  
                    <div class="n404-field"><div class="n404-lbl">1kHz <span id="lbl-eq3">+0.0dB</span></div><input data-param="eq3" type="range" min="-24" max="48" step="0.5" value="0"></div>  
                    <div class="n404-field"><div class="n404-lbl">3kHz <span id="lbl-eq4">+0.0dB</span></div><input data-param="eq4" type="range" min="-24" max="48" step="0.5" value="0"></div>  
                    <div class="n404-field"><div class="n404-lbl">6kHz <span id="lbl-eq5">+0.0dB</span></div><input data-param="eq5" type="range" min="-24" max="48" step="0.5" value="0"></div>  
                    <div class="n404-field"><div class="n404-lbl">12kHz <span id="lbl-eq6">+0.0dB</span></div><input data-param="eq6" type="range" min="-24" max="48" step="0.5" value="0"></div>  
                </div>  
            </div>  

            <div class="n404-actions">  
                <button id="btn-toggle-louder" class="n404-btn clear" type="button">LOUDER (ON)</button>  
                <button id="btn-turbo" class="n404-btn turbo" type="button">MAX BOOST (OFF)</button>  
                <button id="btn-repeat" class="n404-btn repeat" type="button">REPEAT (OFF)</button>  
                <button id="btn-mute" class="n404-btn" type="button">MUTE</button>  
                <button id="btn-reset" class="n404-btn reset" type="button">RESET</button>  
            </div>  

            <div class="n404-footer-brand">Made By NOOR-404</div>  
        </div>  
      `;  
      document.body.appendChild(panel);  
    },  

    bind() {  
      const btnCollapse = document.getElementById("btn-collapse");  
      const btnLock = document.getElementById("btn-lock");  
      const panelBody = document.getElementById("n404-body");  
      const btnToggleLouder = document.getElementById("btn-toggle-louder");  
      const btnTurbo = document.getElementById("btn-turbo");  
      const btnRepeat = document.getElementById("btn-repeat");  
      const btnMute = document.getElementById("btn-mute");  
      const btnReset = document.getElementById("btn-reset");  

      const handleCollapse = (e) => {  
        e.stopPropagation();  
        e.preventDefault();  
        currentState.collapsed = !currentState.collapsed;  
        panelBody.style.display = currentState.collapsed ? "none" : 'block';  
        btnCollapse.textContent = currentState.collapsed ? "MINIMIZE (ON)" : "MINIMIZE (OFF)";  
        btnCollapse.classList.toggle("active", currentState.collapsed);  
      };  

      const handleLock = (e) => {  
        e.stopPropagation();  
        e.preventDefault();  
        currentState.panelLocked = !currentState.panelLocked;  
        btnLock.textContent = currentState.panelLocked ? "LOCK (ON)" : "LOCK (OFF)";  
        btnLock.classList.toggle("active", currentState.panelLocked);  
      };  

      btnCollapse.addEventListener("click", handleCollapse);  
      btnCollapse.addEventListener("touchstart", handleCollapse);  

      btnLock.addEventListener("click", handleLock);  
      btnLock.addEventListener("touchstart", handleLock);  

      btnToggleLouder.addEventListener("click", () => {  
        currentState.louderDisabled = !currentState.louderDisabled;  
        btnToggleLouder.textContent = currentState.louderDisabled ? "LOUDER (OFF)" : "LOUDER (ON)";  
        btnToggleLouder.classList.toggle("active", !currentState.louderDisabled);  
        AudioInterceptor.pushParamsFast();  
      });  

      btnTurbo.addEventListener("click", () => {  
        currentState.turboActive = !currentState.turboActive;  
        btnTurbo.textContent = currentState.turboActive ? "MAX BOOST (ON)" : "MAX BOOST (OFF)";  
        btnTurbo.classList.toggle("active", currentState.turboActive);  
        AudioInterceptor.pushParamsFast();  
      });  

      btnRepeat.addEventListener("click", () => {  
        if (currentState.repeatState === 0) {  
          AudioInterceptor.startVoiceRecording();  
        } else if (currentState.repeatState === 1) {  
          AudioInterceptor.stopVoiceRecordingAndStartLoop();  
        } else if (currentState.repeatState === 2) {  
          AudioInterceptor.stopVoiceRepeat();  
          this.setStatus("MAX POWER");  
        }  
      });  

      btnMute.addEventListener("click", () => {  
        currentState.muteActive = !currentState.muteActive;  
        btnMute.textContent = currentState.muteActive ? "UNMUTE" : "MUTE";  
        btnMute.classList.toggle("active", currentState.muteActive);  
        AudioInterceptor.pushParamsFast();  
      });  

      btnReset.addEventListener("click", () => {  
        this.resetToDefaults();  
      });  

      document.querySelectorAll('#n404-panel input[type="range"]').forEach(input => {  
        const preventScroll = (e) => e.stopPropagation();  
        input.addEventListener("touchstart", preventScroll, { passive: true });  
        input.addEventListener("touchmove", preventScroll, { passive: true });  

        const updateVal = (e) => {  
          const param = e.target.dataset.param;  
          currentState[param] = parseFloat(e.target.value);  

          this.updateValueLabel(param);  
          AudioInterceptor.schedulePushParams();  
        };  

        input.addEventListener("input", updateVal);  
        input.addEventListener("change", updateVal);  
      });  
    },  

    enableDrag() {  
      const panel = document.getElementById("n404-panel");  
      const header = document.getElementById("n404-header");  

      let isDragging = false;  
      let startX = 0, startY = 0;  
      let initialLeft = 0, initialTop = 0;  

      const onStart = (clientX, clientY, target) => {  
        if (currentState.panelLocked) return;  
        if (target.closest(".n404-hdr-btns") || target.tagName === 'INPUT' || target.tagName === 'BUTTON') return;  

        isDragging = true;  
        startX = clientX;  
        startY = clientY;  
        initialLeft = panel.offsetLeft;  
        initialTop = panel.offsetTop;  
      };  

      const onMove = (clientX, clientY, e) => {  
        if (!isDragging) return;  
        if (e && e.cancelable) e.preventDefault();  

        const dx = clientX - startX;  
        const dy = clientY - startY;  

        const maxX = window.innerWidth - panel.offsetWidth;  
        const maxY = window.innerHeight - panel.offsetHeight;  

        const nextX = Math.min(Math.max(0, initialLeft + dx), maxX);  
        const nextY = Math.min(Math.max(0, initialTop + dy), maxY);  

        panel.style.left = nextX + 'px';  
        panel.style.top = nextY + 'px';  

        currentState.panelX = nextX;  
        currentState.panelY = nextY;  
      };  

      const onEnd = () => {  
        if (isDragging) {  
          isDragging = false;  
        }  
      };  

      header.addEventListener("mousedown", e => onStart(e.clientX, e.clientY, e.target));  
      window.addEventListener("mousemove", e => onMove(e.clientX, e.clientY, e));  
      window.addEventListener("mouseup", onEnd);  

      header.addEventListener("touchstart", e => {  
        if (e.touches.length === 1) {  
          onStart(e.touches[0].clientX, e.touches[0].clientY, e.target);  
        }  
      }, { passive: false });  

      window.addEventListener("touchmove", e => {  
        if (isDragging && e.touches.length === 1) {  
          onMove(e.touches[0].clientX, e.touches[0].clientY, e);  
        }  
      }, { passive: false });  

      window.addEventListener("touchend", onEnd);  
    },  

    injectStyles() {  
      const style = document.createElement("style");  
      style.textContent = `  
        #n404-panel {  
          --accent: #ff0000;  
          --border: #ff0000;  
          position: fixed;  
          top: 20px;  
          left: 20px;  
          width: 320px;  
          background: rgba(12, 12, 16, 0.94);  
          border: 1px solid var(--border);  
          box-shadow: 0 0 20px rgba(0,0,0,0.8), 0 0 10px var(--accent);  
          border-radius: 8px;  
          color: #fff;  
          z-index: 9999999;  
          font-family: 'Segoe UI', system-ui, sans-serif;  
          user-select: none;  
          padding: 12px;  
          backdrop-filter: blur(8px);  
          overflow: hidden;  
          touch-action: none;  
        }  

        #n404-bg-canvas {  
          position: absolute;  
          top: 0; left: 0; width: 100%; height: 100%;  
          pointer-events: none;  
          z-index: 0;  
        }  

        .n404-header, #n404-body {  
          position: relative;  
          z-index: 1;  
        }  

        .n404-header {  
          display: flex;  
          justify-content: space-between;  
          align-items: center;  
          border-bottom: 1px solid var(--border);  
          padding-bottom: 6px;  
          cursor: move;  
          touch-action: none;  
        }  

        .n404-title {  
          font-size: 11px;  
          font-weight: 800;  
          color: var(--accent);  
          letter-spacing: 1px;  
        }  

        .n404-hdr-btns {  
          display: flex;  
          gap: 4px;  
          z-index: 2;  
        }  

        .n404-action-tag-btn {  
          background: transparent;  
          border: 1px solid var(--border);  
          color: var(--accent);  
          font-weight: bold;  
          font-size: 8px;  
          padding: 3px 5px;  
          border-radius: 3px;  
          cursor: pointer;  
          transition: 0.2s;  
          pointer-events: auto;  
        }  

        .n404-action-tag-btn.active,   
        .n404-action-tag-btn:hover {  
          background: var(--accent);  
          color: #000;  
          box-shadow: 0 0 8px var(--accent);  
        }  

        .n404-visual {  
          height: 50px;  
          background: rgba(0,0,0,0.6);  
          border: 1px solid #333;  
          margin: 10px 0 6px 0;  
          border-radius: 4px;  
          overflow: hidden;  
          position: relative;  
        }  

        #n404-canvas {  
          width: 100%;  
          height: 100%;  
          display: block;  
        }  

        .n404-bar {  
          display: flex;  
          align-items: center;  
          gap: 6px;  
          font-size: 10px;  
          color: var(--accent);  
          margin-bottom: 8px;  
          font-weight: bold;  
        }  

        .n404-dot {  
          width: 6px;  
          height: 6px;  
          background: var(--accent);  
          border-radius: 50%;  
          box-shadow: 0 0 6px var(--accent);  
        }  

        .n404-palette-box {  
          margin-bottom: 10px;  
        }  

        .n404-palette-container {  
          position: relative;  
          height: 16px;  
          border-radius: 8px;  
          overflow: visible;  
          margin-top: 4px;  
          cursor: pointer;  
          touch-action: none;  
        }  

        #n404-palette-canvas {  
          width: 100%;  
          height: 100%;  
          border-radius: 8px;  
          display: block;  
        }  

        #n404-color-dot {  
          position: absolute;  
          top: 50%; left: 10px;  
          transform: translate(-50%, -50%);  
          width: 14px; height: 14px;  
          border-radius: 50%;  
          background: #fff;  
          border: 2px solid #000;  
          box-shadow: 0 0 6px #fff;  
          pointer-events: none;  
        }  

        .n404-field {  
          margin-bottom: 8px;  
        }  

        .n404-lbl {  
          display: flex;  
          justify-content: space-between;  
          font-size: 10px;  
          color: #ccc;  
          margin-bottom: 3px;  
          font-weight: 600;  
        }  

        .n404-lbl span {  
          color: var(--accent);  
        }  

        .n404-eq-grid {  
          display: grid;  
          grid-template-columns: 1fr 1fr;  
          gap: 6px 12px;  
          border-top: 1px dashed var(--border);  
          padding-top: 8px;  
          margin-top: 8px;  
        }  

        #n404-panel input[type="range"] {  
          -webkit-appearance: none;  
          appearance: none;  
          width: 100%;  
          height: 8px;  
          background: rgba(255, 255, 255, 0.15);  
          border: 1px solid rgba(255, 255, 255, 0.1);  
          border-radius: 4px;  
          outline: none;  
          cursor: pointer;  
          touch-action: none;  
          position: relative;  
        }  

        #n404-panel input[type="range"]::-webkit-slider-runnable-track {  
          height: 8px;  
          border-radius: 4px;  
          background: linear-gradient(90deg, rgba(255,255,255,0.2) 0%, var(--accent) 100%);  
          border: 1px solid rgba(0,0,0,0.3);  
        }  

        #n404-panel input[type="range"]::-webkit-slider-thumb {  
          -webkit-appearance: none;  
          appearance: none;  
          width: 16px;  
          height: 16px;  
          margin-top: -5px;  
          border-radius: 50%;  
          background: #ffffff;  
          border: 2px solid var(--accent);  
          cursor: pointer;  
          box-shadow: 0 0 10px var(--accent);  
        }  

        .n404-actions {  
          display: flex;  
          flex-wrap: wrap;  
          gap: 6px;  
          margin-top: 10px;  
        }  

        .n404-btn {  
          flex: 1 1 45%;  
          background: transparent;  
          border: 1px solid var(--border);  
          color: var(--accent);  
          font-weight: bold;  
          font-size: 10px;  
          padding: 6px 0;  
          border-radius: 4px;  
          cursor: pointer;  
          transition: 0.2s;  
        }  

        .n404-btn.active, .n404-btn:hover {  
          background: var(--accent);  
          color: #000;  
          box-shadow: 0 0 10px var(--accent);  
        }  

        .n404-footer-brand {  
          text-align: center;  
          font-size: 9px;  
          color: rgba(255, 255, 255, 0.4);  
          letter-spacing: 1.5px;  
          margin-top: 10px;  
          text-transform: uppercase;  
          font-weight: 700;  
          border-top: 1px solid rgba(255, 255, 255, 0.05);  
          padding-top: 6px;  
        }  
      `;  
      document.head.appendChild(style);  
    }  
  };  

  UIController.init();
}
})();
