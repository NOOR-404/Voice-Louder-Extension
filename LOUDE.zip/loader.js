(function () {'use strict';
  chrome.runtime.sendMessage({ action: "checkServerStatus" }, (response) => {
    let statusData = { success: false, data: null };
    if (response && response.success) {statusData = { success: true, data: response.data };}window.postMessage({ type: "NOOR404_SERVER_STATUS", statusData: statusData }, "*");});
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('injector.js');
  script.onload = function () { script.remove(); };
  (document.head || document.documentElement).appendChild(script);})();